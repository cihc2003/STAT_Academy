using Microsoft.AspNetCore.Identity;
using System.ComponentModel.DataAnnotations;

namespace STAT_Academy.Web.Models;

public class ApplicationUser : IdentityUser
{
    [Required, StringLength(120)]
    public string FullName { get; set; } = string.Empty;

    [StringLength(30)]
    public string DocumentId { get; set; } = string.Empty;

    public bool IsActive { get; set; } = true;
}
