using System.ComponentModel.DataAnnotations;

namespace STAT_Academy.Web.ViewModels;

public class RegisterViewModel
{
    [Required, Display(Name = "Nombre completo"), StringLength(120)]
    public string FullName { get; set; } = string.Empty;
    [Required, EmailAddress, Display(Name = "Correo electronico")]
    public string Email { get; set; } = string.Empty;
    [Required, Phone, Display(Name = "Telefono")]
    public string PhoneNumber { get; set; } = string.Empty;
    [Required, DataType(DataType.Password), MinLength(6), Display(Name = "Contrasena")]
    public string Password { get; set; } = string.Empty;
    [Required, Compare(nameof(Password)), DataType(DataType.Password), Display(Name = "Confirmar contrasena")]
    public string ConfirmPassword { get; set; } = string.Empty;
}

public class LoginViewModel
{
    [Required, EmailAddress]
    public string Email { get; set; } = string.Empty;
    [Required, DataType(DataType.Password)]
    public string Password { get; set; } = string.Empty;
    public bool RememberMe { get; set; }
}

public class ForgotPasswordViewModel
{
    [Required, EmailAddress]
    public string Email { get; set; } = string.Empty;
}

public class CartItemViewModel
{
    public int ProductId { get; set; }
    public string Name { get; set; } = string.Empty;
    public decimal Price { get; set; }
    public int Quantity { get; set; }
    public decimal Subtotal => Price * Quantity;
}
