using System.ComponentModel.DataAnnotations;

namespace STAT_Academy.Web.Models;

public abstract class AuditableEntity
{
    public int Id { get; set; }
    public bool IsActive { get; set; } = true;
    public bool IsDeleted { get; set; }
    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
}

public class Supplier : AuditableEntity
{
    [Required, StringLength(120)]
    public string Name { get; set; } = string.Empty;
    [Required, EmailAddress, StringLength(160)]
    public string Email { get; set; } = string.Empty;
    [Required, StringLength(30)]
    public string Phone { get; set; } = string.Empty;
    [StringLength(220)]
    public string Address { get; set; } = string.Empty;
}

public class Product : AuditableEntity
{
    [Required, StringLength(140)]
    public string Name { get; set; } = string.Empty;
    [Required, StringLength(80)]
    public string Category { get; set; } = string.Empty;
    [Required, StringLength(500)]
    public string Description { get; set; } = string.Empty;
    [Range(0.01, 999999)]
    public decimal Price { get; set; }
    [Range(0, 99999)]
    public int Stock { get; set; }
    public int? SupplierId { get; set; }
    public Supplier? Supplier { get; set; }
}

public class Course : AuditableEntity
{
    [Required, StringLength(140)]
    public string Title { get; set; } = string.Empty;
    [Required, StringLength(80)]
    public string Category { get; set; } = string.Empty;
    [Required, StringLength(700)]
    public string Description { get; set; } = string.Empty;
    [Range(1, 80)]
    public int DurationWeeks { get; set; }
    [Range(0, 999999)]
    public decimal Price { get; set; }
    public string? TutorId { get; set; }
    public ApplicationUser? Tutor { get; set; }
}

public class Enrollment : AuditableEntity
{
    [Required]
    public string StudentId { get; set; } = string.Empty;
    public ApplicationUser? Student { get; set; }
    public int CourseId { get; set; }
    public Course? Course { get; set; }
    [Required, StringLength(30)]
    public string Status { get; set; } = "Pendiente";
}

public class CourseMaterial : AuditableEntity
{
    public int CourseId { get; set; }
    public Course? Course { get; set; }
    [Required, StringLength(120)]
    public string Title { get; set; } = string.Empty;
    [Required, StringLength(350)]
    public string Url { get; set; } = string.Empty;
    [Range(1, 80)]
    public int Week { get; set; } = 1;
}

public class CourseTask : AuditableEntity
{
    public int CourseId { get; set; }
    public Course? Course { get; set; }
    [Required, StringLength(120)]
    public string Title { get; set; } = string.Empty;
    [Required, StringLength(500)]
    public string Instructions { get; set; } = string.Empty;
    public DateTime DueDate { get; set; } = DateTime.UtcNow.AddDays(7);
}

public class BlogPost : AuditableEntity
{
    [Required, StringLength(160)]
    public string Title { get; set; } = string.Empty;
    [Required, StringLength(120)]
    public string Category { get; set; } = string.Empty;
    [Required, StringLength(280)]
    public string Summary { get; set; } = string.Empty;
    [Required]
    public string Content { get; set; } = string.Empty;
}

public class Order : AuditableEntity
{
    [Required]
    public string UserId { get; set; } = string.Empty;
    public ApplicationUser? User { get; set; }
    public decimal Total { get; set; }
    [Required, StringLength(30)]
    public string Status { get; set; } = "Confirmado";
    public List<OrderItem> Items { get; set; } = [];
}

public class OrderItem
{
    public int Id { get; set; }
    public int OrderId { get; set; }
    public Order? Order { get; set; }
    public int ProductId { get; set; }
    public Product? Product { get; set; }
    public int Quantity { get; set; }
    public decimal UnitPrice { get; set; }
}

public class Invoice : AuditableEntity
{
    public int OrderId { get; set; }
    public Order? Order { get; set; }
    [Required, StringLength(40)]
    public string Number { get; set; } = string.Empty;
    public decimal Total { get; set; }
    public DateTime IssuedAt { get; set; } = DateTime.UtcNow;
}
