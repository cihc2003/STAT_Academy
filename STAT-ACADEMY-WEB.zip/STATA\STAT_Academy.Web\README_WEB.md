# STAT Academy Web

Proyecto ASP.NET Core MVC .NET 8 con Razor Views, Bootstrap 5, Entity Framework Core, SQL Server LocalDB e Identity.

## Como ejecutar

1. Abrir `STAT_Academy.sln` en Visual Studio.
2. Seleccionar `STAT_Academy.Web` como proyecto de inicio.
3. Restaurar paquetes NuGet si Visual Studio lo solicita.
4. Ejecutar con IIS Express o perfil `http`.

La aplicacion crea automaticamente la base:

`STAT_Academy_Platform_Web`

usando SQL Server LocalDB y `EnsureCreated`.

## Usuarios iniciales

- Administrador: `admin@statmedical.com` / `Admin123!`
- Tutor: `tutor@statmedical.com` / `Tutor123!`
- Estudiante: `estudiante@statmedical.com` / `Estudiante123!`

## Modulos incluidos

- Inicio con STATMEDICAL, cursos, productos y blog.
- Registro, login, logout y recuperacion de contrasena.
- Roles: Administrador, Tutor y Estudiante.
- Dashboard administrativo.
- Productos, proveedores, cursos, matriculas, blog, pedidos y facturas.
- Area de estudiante: mis cursos, materiales, tareas, pedidos y facturas.
- Area de tutor: cursos asignados, materiales, tareas y estudiantes.
- Carrito de compras con confirmacion de pedido y factura.
- Soft delete y activacion/desactivacion por estado.

## API existente

La API no fue modificada. El Web incluye `ApiUserGateway` como complemento para verificar disponibilidad del endpoint de usuarios desde el dashboard administrativo.
